# ANNER — Neon Game Hub

A single-page gaming website with:
- Neon green ANNER home screen
- 3D falling snow background using Three.js
- 20 responsive game slots
- Game-slot modal interaction
- Mobile-friendly layout
- No build step required

## Run it

Open `index.html` in a modern browser.

## Add your games

Edit the `games` array in `script.js`. You can add a URL, embed, or local game path and change the modal's Launch behavior.

The snow effect loads Three.js from cdnjs, so the browser needs internet access for the 3D background.
